# -*- coding: utf-8 -*-

'''this script is recommanded to run under python3'''

from os import getcwd, listdir, path
import pandas as pd
from pandas import DataFrame

with open('temp/intersection_source_file_list.txt') as f:
    intersection_source_file_list = f.readlines()
    f.close()

intersection_source_file_list_2 = []
for i in intersection_source_file_list:
    intersection_source_file_list_2.append(i.strip().replace('temp/source/Source_Sheet_', '').replace('.csv', ''))

intersection_source_file_list = intersection_source_file_list_2
# print(intersection_source_file_list)


# set output file name and path
root_path = os.getcwd()
ls_target = os.listdir(root_path + '/inputs/target')
    
if not ls_target == []:
    ls_target_0 = 'output/' + ls_target[0]
    ls_target_0 = ls_target_0.replace('.xlsx', '_Updated.xlsx')
    print('\nStep 04: Set Output File: %s' % ls_target_0)
else:
    print('ERROR: Could Not find Target File, please check it under inputs\\target\\ folder!')
    exit(1)

# An example for write an Excel from data in "dict" - which can be read from another XLSX file
'''
# An example for data format for XLSX (dict), each "key" is a column:
data = {
    'name':['Alice', 'Bob', 'Charlie'],
    'age':[11, 12, 13],
    'sex':['Female', 'Male', 'Male'],
}
'''
def writeExcelDemo():
    headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
            'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component']
    data = {}
    for header in headers:
        data[header] = []  # init a key in dict
        data[header].append('example')
    df = DataFrame(data)
    df.to_excel('target_file.xlsx', sheet_name='Sheet1', index=False, header=True)

# for a "data" (2-dimension list) convert numbers from str to int
def Str2Int(data):
    new_data = []
    for row in data.values:
        # change '/' to '\', only the first column
        try:
            row[0] = row[0].replace('/', '\\')
        except:
            pass
        # convert numbers from str to int
        new_row = []
        for col in row:
            try:
                new_col = int(col)
            except:
                new_col = col
            new_row.append(new_col)
        new_data.append(new_row)
    return new_data

# combine csv's of each component to an entire Excel table
def Step07():
    first_sheet_in_target_xlsx = 'temp/target/Target_Sheet_QAC_QACPP_Warnings_Stat_new.csv'
    source_file_template = 'temp/target/Target_Sheet_'   # temp/target/Target_Sheet_BSW_C_target.csv
    target_file = ls_target_0

    # read first sheet from csv format, the output is 2-dimension list
    data = pd.read_csv(first_sheet_in_target_xlsx, sep=',', header=None)  # without attribute "header=None", the first line will be missing
    # convert numbers from str to int
    new_data = Str2Int(data)
    # prepare to write the sheet to Excel
    df0 = DataFrame(new_data)

    # read other sheets
    dfs = []
    for item in intersection_source_file_list:
        middleware_target = source_file_template + item + '_target.csv'
        # print(middleware_target)

        if os.path.exists(middleware_target):
            print("* Merging " + middleware_target)
            this_df = {}
            # read csv, if without attribute "header=None", the first line will be missing
            data = pd.read_csv(middleware_target, sep=',', header=None)
            # convert numbers from str to int
            new_data = Str2Int(data)
            # prepare to write the sheet to Excel
            this_df['sheet_title'] = item
            this_df['DF']= DataFrame(new_data)
            dfs.append(this_df)
        

    # *** Write Excel... ***
    # if only one sheet need:
    # df0.to_excel(target_file, sheet_name='QAC_QACPP_Warnings_Stat_new', index=False, header=False)

    # if more than one sheets need:
    with pd.ExcelWriter(target_file) as writer:
        df0.to_excel(writer, sheet_name='QAC_QACPP_Warnings_Stat_new', index=False, header=False)
        for df in dfs:
            df['DF'].to_excel(writer, sheet_name=df['sheet_title'], index=False, header=False)


print("Merging CSV to XLSX...")
Step07()

print("\nAll Finished.\nOutput: %s" % ls_target_0)
print("")  # leave an empty line
