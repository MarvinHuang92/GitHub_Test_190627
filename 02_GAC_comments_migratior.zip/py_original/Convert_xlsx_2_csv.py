# -*- coding: utf-8 -*-

'''this script is recommanded to run under python3'''

import os, csv
import pandas as pd
from pandas import DataFrame

###################################### Stage 01: Convert XLSX to separated CSV ##################################

def convert_xlsx_to_csv (source_file, sheet_name, target_file):
    data = pd.read_excel(source_file, sheet_name, index_col=0)  # without attribute "index_col=0", there will be an extra colomn at the beginning of csv
    data.to_csv(target_file, encoding='utf-8')

# get input file names
root_path = os.getcwd()
ls_source = os.listdir(root_path + '/inputs/source')
ls_target = os.listdir(root_path + '/inputs/target')

if not ls_source == []:
    ls_source_0 = 'inputs/source/' + ls_source[0]
    print('Read Source File: %s' % ls_source_0)
else:
    print('ERROR: Could Not find Source File, please check it under inputs\\source\\ folder!')
    exit(1)
    
if not ls_target == []:
    ls_target_0 = 'inputs/target/' + ls_target[0]
    print('Read Target File: %s' % ls_target_0)
else:
    print('ERROR: Could Not find Target File, please check it under inputs\\target\\ folder!')
    exit(1)
    
print('')  # leave an empty line

# read all sheet names from target/source xlsx
source_sheet_list = []
target_sheet_list = []
intersection_source_file_list = []

print('Step 00: Converting XLSX into separated CSV sheets...')

# generate CSV files: source
source_file = ls_source_0
print('Source File: %s\n' % source_file)

df = pd.read_excel(source_file, sheet_name=None)
for sheet_name in df.keys():
    print(' - Find Sheet: %s' % sheet_name)
    source_sheet_list.append(sheet_name)
    target_file = 'temp/source/Source_Sheet_%s.csv' % sheet_name
    convert_xlsx_to_csv (source_file, sheet_name, target_file)
print('')  # leave an empty line

# generate CSV files: target
source_file = ls_target_0
print('Target File: %s\n' % source_file)

df = pd.read_excel(source_file, sheet_name=None)
for sheet_name in df.keys():
    print(' - Find Sheet: %s' % sheet_name)
    target_sheet_list.append(sheet_name)
    target_file = 'temp/target/Target_Sheet_%s.csv' % sheet_name
    convert_xlsx_to_csv (source_file, sheet_name, target_file)
print('')  # leave an empty line

if target_sheet_list != source_sheet_list:
    print("*** Warning: There is difference between Source and Target Sheet names, \
        only their intersection sheets will be used for next processing. ***")
else:
    print("*** There is no difference between Source and Target Sheet names. All OK (^0v0^) ***")
print('')  # leave an empty line

# intersection_source_file_list, only them will be processed in next steps

# 如果使用交集，生成的csv sheet顺序会乱掉，暂时不考虑交集，直接用source sheet list的顺序
# for sheet_name in list(set(source_sheet_list).intersection(set(target_sheet_list))):
for sheet_name in source_sheet_list:
    csv_name = 'temp/source/Source_Sheet_%s.csv' % sheet_name
    if not sheet_name == 'QAC_QACPP_Warnings_Stat_new':
        intersection_source_file_list.append(csv_name)

with open('temp/intersection_source_file_list.txt', 'w') as f:
    f.writelines(line + '\n' for line in intersection_source_file_list)
    f.close()

############################### Stage 02: Core Functions ######################################


with open('temp/intersection_source_file_list.txt') as f:
    intersection_source_file_list = f.readlines()
    f.close()

# 裁剪结尾的\n
intersection_source_file_list_2 = []
for i in intersection_source_file_list:
    intersection_source_file_list_2.append(i.strip())

intersection_source_file_list = intersection_source_file_list_2

# print(intersection_source_file_list)

intersection_target_file_list = []
for i in intersection_source_file_list:
    intersection_target_file_list.append(i.replace('source/Source', 'target/Target'))


# Step01 依次读取每个csv，给结尾增加一列 Flag
# Flag = Filename + Message text

def Step01(source_file, target_file):
    # simply add a "Flag" column into the source file
    headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
        'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component','Comments','Flag']

    rows = []
    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first 1 line
                # print(row)  # this will print the whole table
                # print(row)[0]  # this will print the 1st column
                filepath = row[0].replace('\\', '/')  # replace '\' with '/' because '\' makes re.match cannot work well
                # 模糊处理cubas_gen中关于车型的名称，注意replace A18Y放在A18之前，防止生成AXXY这种错误结果
                flag_this_row = filepath.replace('A13', 'AXX').replace('A18Y', 'AXX').replace('A29', 'AXX').replace('A18', 'AXX') + row[4]
                try:
                    this_row = [filepath,row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],flag_this_row]
                    print('Step 01 OK. @ "%s" Line %d' %(source_file, rowindex))
                except:
                    this_row = [filepath,row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],'',flag_this_row]
                    print('Warning #01: No comments found in target file, filled it with an empty string. @ "%s" Line %d' %(source_file, rowindex))
                rows.append(this_row)
            rowindex += 1

    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)

# 执行 Step01 - 遍历 source CSV
intersection_source_file_list_for_02 = []
intersection_target_file_list_for_02 = []
for source_file in intersection_source_file_list:
    target_file = source_file.replace('.csv', '_flag.csv')
    intersection_source_file_list_for_02.append(target_file)
    Step01(source_file, target_file)
# 遍历 target CSV
for source_file in intersection_target_file_list:
    target_file = source_file.replace('.csv', '_flag.csv')
    intersection_target_file_list_for_02.append(target_file)
    Step01(source_file, target_file)
        

# 读取每一个 source csv，生成对应的字典 （名称为 Source_XXX_dict.csv）
def Step02(source_file, target_file):
    # stat based on filename and severity
    headers = ['Flag','Comments', 'Num']
    rows = []

    flag_existed = []  # 记录所有已经存在的 flag： 如果是新的flag ，加入这个列表，如果是旧的flag ，将对应的num +1

    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first line
                # no need to replace '\' with '/' again
                
                r_flag = row[12]
                r_comments = row[11]
                
                if r_flag not in flag_existed:
                    flag_existed.append(r_flag)
                    this_row = [r_flag, r_comments, 1]  # Flag and Comments, number
                    rows.append(this_row)  # rows and flag_existed share the same index "p"
                else:
                    p = flag_existed.index(r_flag)  # return the index of an item within a list, start from 0
                    rows[p][2] += 1  # num所在的列index为2
            rowindex += 1

    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)
        
intersection_source_file_list_for_03 = []
for source_file in intersection_source_file_list_for_02:
    target_file = source_file.replace('_flag.csv', '_dict.csv')
    intersection_source_file_list_for_03.append(target_file)
    Step02(source_file, target_file)

    
# 读取每一个target csv，通过查字典，写入comments
def Step03(source_file, dictionary_file, target_file):
    # stat based on filename and severity
    headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
        'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component','Comments']
    
    comment_dict_list = []
    with open(dictionary_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first 1 line
                # print(row)  # this will print the whole table
                # print(row)[0]  # this will print the 1st column
                this_row = {'Flag':row[0], 'Comments':row[1]}
                comment_dict_list.append(this_row)
            rowindex += 1
    # print(comment_dict_list)
    
    rows = []
    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first 1 line
                # print(row)  # this will print the whole table
                # print(row)[0]  # this will print the 1st column
                
                r_flag = row[12]
                r_comments = ''
                
                for i in comment_dict_list:
                    if r_flag == i['Flag']:
                        r_comments = i['Comments']
                
                this_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],r_comments]  # Do not need to print Flag again
                
                if r_comments == '':
                    print ('Warning #0301: Comments not found from source. @ "%s" Line %d' %(target_file, rowindex))
                else:  # Comments found from source
                    if row[11].strip() != '':  # 防止覆盖原有的评论
                        print('Step 0302: Comments already exists in target file, do not overwrite it. @ "%s" Line %d' %(target_file, rowindex))
                        this_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11]]  # Do not need to print Flag again
                    else:
                        print('Step 0302 OK: Comments Migrated Done. @ "%s" Line %d' %(target_file, rowindex))
                        
                rows.append(this_row)
            rowindex += 1

    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)

for dictionary_file in intersection_source_file_list_for_03:
    target_file = dictionary_file.replace('_dict.csv', '_target.csv').replace('source/Source', 'target/Target')
    source_file = target_file.replace('_target.csv', '_flag.csv')
    
    print('')
    print('Source: %s' % source_file)
    print('Target: %s' % target_file)
    print('Dictionary: %s' % dictionary_file)
    print('')
    
    Step03(source_file, dictionary_file, target_file)
    


######################################### stage 03: Combine all CSV into XLSX  ############################################

with open('temp/intersection_source_file_list.txt') as f:
    intersection_source_file_list = f.readlines()
    f.close()

intersection_source_file_list_2 = []
for i in intersection_source_file_list:
    intersection_source_file_list_2.append(i.strip().replace('temp/source/Source_Sheet_', '').replace('.csv', ''))

intersection_source_file_list = intersection_source_file_list_2
# print(intersection_source_file_list)


# set output file name and path
root_path = os.getcwd()
ls_target = os.listdir(root_path + '/inputs/target')
    
if not ls_target == []:
    ls_target_0 = 'output/' + ls_target[0]
    ls_target_0 = ls_target_0.replace('.xlsx', '_Updated.xlsx')
    print('\nStep 04: Set Output File: %s' % ls_target_0)
else:
    print('ERROR: Could Not find Target File, please check it under inputs\\target\\ folder!')
    exit(1)

# An example for write an Excel from data in "dict" - which can be read from another XLSX file
'''
# An example for data format for XLSX (dict), each "key" is a column:
data = {
    'name':['Alice', 'Bob', 'Charlie'],
    'age':[11, 12, 13],
    'sex':['Female', 'Male', 'Male'],
}
'''
def writeExcelDemo():
    headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
            'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component']
    data = {}
    for header in headers:
        data[header] = []  # init a key in dict
        data[header].append('example')
    df = DataFrame(data)
    df.to_excel('target_file.xlsx', sheet_name='Sheet1', index=False, header=True)

# for a "data" (2-dimension list) convert numbers from str to int
def Str2Int(data):
    new_data = []
    for row in data.values:
        # change '/' to '\', only the first column
        try:
            row[0] = row[0].replace('/', '\\')
        except:
            pass
        # convert numbers from str to int
        new_row = []
        for col in row:
            try:
                new_col = int(col)
            except:
                new_col = col
            new_row.append(new_col)
        new_data.append(new_row)
    return new_data

# combine csv's of each component to an entire Excel table
def Step07():
    first_sheet_in_target_xlsx = 'temp/target/Target_Sheet_QAC_QACPP_Warnings_Stat_new.csv'
    source_file_template = 'temp/target/Target_Sheet_'   # temp/target/Target_Sheet_BSW_C_target.csv
    target_file = ls_target_0

    # read first sheet from csv format, the output is 2-dimension list
    data = pd.read_csv(first_sheet_in_target_xlsx, sep=',', header=None)  # without attribute "header=None", the first line will be missing
    # convert numbers from str to int
    new_data = Str2Int(data)
    # prepare to write the sheet to Excel
    df0 = DataFrame(new_data)

    # read other sheets
    dfs = []
    for item in intersection_source_file_list:
        middleware_target = source_file_template + item + '_target.csv'
        # print(middleware_target)

        if os.path.exists(middleware_target):
            print("* Merging " + middleware_target)
            this_df = {}
            # read csv, if without attribute "header=None", the first line will be missing
            data = pd.read_csv(middleware_target, sep=',', header=None)
            # convert numbers from str to int
            new_data = Str2Int(data)
            # prepare to write the sheet to Excel
            this_df['sheet_title'] = item
            this_df['DF']= DataFrame(new_data)
            dfs.append(this_df)
        

    # *** Write Excel... ***
    # if only one sheet need:
    # df0.to_excel(target_file, sheet_name='QAC_QACPP_Warnings_Stat_new', index=False, header=False)

    # if more than one sheets need:
    with pd.ExcelWriter(target_file) as writer:
        df0.to_excel(writer, sheet_name='QAC_QACPP_Warnings_Stat_new', index=False, header=False)
        for df in dfs:
            df['DF'].to_excel(writer, sheet_name=df['sheet_title'], index=False, header=False)


print("Merging CSV to XLSX...")
Step07()

print("\nAll Finished.\nOutput: %s" % ls_target_0)
print("")  # leave an empty line



