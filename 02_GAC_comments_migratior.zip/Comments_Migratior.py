# -*- coding: utf-8 -*-

'''this script is recommanded to run under python3'''

from os import getcwd, listdir, path
from sys import argv
import csv
import pandas as pd
from pandas import DataFrame

there_are_messages_to_be_printed_in_the_end = False
messages_to_be_printed_in_the_end = ''

####################### Get Input: Which kind of report to be migrated? ############################
selection = argv[1]
print('\nUser Input: ' + selection)
print('')

input_folder = ''
if selection == 'QAC':
    input_folder = '01_inputs_qac'
elif selection == 'Coverity':
    input_folder = '02_inputs_coverity'
elif selection == 'Compiler_Warnings':
    input_folder = '03_inputs_compiler_warnings'
else:
    print('Invalid Input! this script will exit.')
    exit(1)

############################# Stage 01: Convert XLSX to separated CSV ##############################

def convert_xlsx_to_csv (source_file, sheet_name, target_file):
    data = pd.read_excel(source_file, sheet_name, index_col=0)  # without attribute "index_col=0", there will be an extra colomn at the beginning of csv
    data.to_csv(target_file, encoding='utf-8')

# get input file names
root_path = getcwd()
ls_source = listdir('%s/%s/source' % (root_path, input_folder))
ls_target = listdir('%s/%s/target' % (root_path, input_folder))

if not ls_source == []:
    ls_source_0 = input_folder + '/source/' + ls_source[0]
    print('Read Source File: %s' % ls_source_0)
else:
    print('ERROR: Could Not find Source File, please check it under %s\\source\\ folder!' % input_folder)
    exit(1)
    
if not ls_target == []:
    ls_target_0 = input_folder + '/target/' + ls_target[0]
    print('Read Target File: %s' % ls_target_0)
else:
    print('ERROR: Could Not find Target File, please check it under %s\\target\\ folder!' % input_folder)
    exit(1)
    
print('')  # leave an empty line

# read all sheet names from target/source xlsx
source_sheet_list = []
target_sheet_list = []
intersection_source_file_list = []

source_but_not_target_file_list = []
target_but_not_source_file_list = []

print('*** Step 00: Converting XLSX into separated CSV sheets...')

# generate CSV files: source
source_file = ls_source_0
print('Source File: %s\n' % source_file)

df = pd.read_excel(source_file, sheet_name=None)
for sheet_name in df.keys():
    print(' - Find Sheet: %s' % sheet_name)
    source_sheet_list.append(sheet_name)
    target_file = 'temp/source/Source_Sheet_%s.csv' % sheet_name
    convert_xlsx_to_csv (source_file, sheet_name, target_file)
print('')  # leave an empty line

# generate CSV files: target
source_file = ls_target_0
print('Target File: %s\n' % source_file)

df = pd.read_excel(source_file, sheet_name=None)
for sheet_name in df.keys():
    print(' - Find Sheet: %s' % sheet_name)
    target_sheet_list.append(sheet_name)
    target_file = 'temp/target/Target_Sheet_%s.csv' % sheet_name
    convert_xlsx_to_csv (source_file, sheet_name, target_file)
print('')  # leave an empty line

# 手动写一个交集算法（可以排除list中元素顺序不同的影响，且交集始终按照 target 集合的顺序排列）
list_equal = True
# 首先计算交集，和B-A
for s in target_sheet_list:
    if s in source_sheet_list:
        intersection_source_file_list.append(s)
    else:
        target_but_not_source_file_list.append(s)
# 然后计算A-B
for s in source_sheet_list:
    if s not in intersection_source_file_list:
        source_but_not_target_file_list.append(s)
# 如果两个差集的任一个不为空，说明两个list不相等
if (source_but_not_target_file_list != []) or (target_but_not_source_file_list != []):
    list_equal = False
    
if list_equal:
    print("*** There is no difference between Source and Target Sheet names. All OK (^0v0^) ***")
else:
    there_are_messages_to_be_printed_in_the_end = True
    messages_to_be_printed_in_the_end = '*** Warning #06: There are differences between Source and Target Sheet names, only their intersection sheets will be used for next processing. ***\
        \n - Sheet(s) in Source XLSX but not in Target: %s, Ignore them;\
        \n - Sheet(s) in Target XLSX but not in Source: %s, Please check them manually.' % (str(source_but_not_target_file_list), str(target_but_not_source_file_list))
    print(messages_to_be_printed_in_the_end)
print('')  # leave an empty line

# intersection_source_file_list, only them will be processed in next steps

# 如果直接使用交集函数，生成的csv sheet顺序会乱掉，故采用上面手写的算法
# for sheet_name in list(set(source_sheet_list).intersection(set(target_sheet_list))):
intersection_source_file_list_2 = []
for sheet_name in intersection_source_file_list:
    csv_name = 'temp/source/Source_Sheet_%s.csv' % sheet_name
    
    starting_sheet_name = ''
    if selection == 'QAC':
        starting_sheet_name = 'QAC_QACPP_Warnings_Stat_new'
    elif selection == 'Coverity':
        starting_sheet_name = 'Coverity_Warnings_Stat'
    elif selection == 'Compiler_Warnings':
        starting_sheet_name = 'Compiler_Warnings_Warnings_Stat'
        
    if not sheet_name == starting_sheet_name:
        intersection_source_file_list_2.append(csv_name)
intersection_source_file_list = intersection_source_file_list_2

with open('temp/intersection_source_file_list.txt', 'w') as f:
    f.writelines(line + '\n' for line in intersection_source_file_list)
    f.close()
if source_but_not_target_file_list != []:
    with open('99_output/source_but_not_target_sheets_%s.txt' % selection, 'w') as f:
        f.writelines(line + '\n' for line in source_but_not_target_file_list)
        f.close()
if target_but_not_source_file_list != []:
    with open('99_output/target_but_not_source_sheets_%s.txt' % selection, 'w') as f:
        f.writelines(line + '\n' for line in target_but_not_source_file_list)
        f.close()

################################## Stage 02: Core Functions ########################################


with open('temp/intersection_source_file_list.txt') as f:
    intersection_source_file_list = f.readlines()
    f.close()

# 裁剪结尾的\n
intersection_source_file_list_2 = []
for i in intersection_source_file_list:
    intersection_source_file_list_2.append(i.strip())

intersection_source_file_list = intersection_source_file_list_2

# print(intersection_source_file_list)

intersection_target_file_list = []
for i in intersection_source_file_list:
    intersection_target_file_list.append(i.replace('source/Source', 'target/Target'))


# Step01 依次读取每个csv，给结尾增加一列 Flag
# Flag = Filename + Message text
print('*** Step 01: Adding "Flag" to each line (Flag = File path + Warning info)... \n')

def Step01(source_file, target_file):
    # simply add a "Flag" column into the source file
    headers = []
    if selection == 'QAC':
        headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
        'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component','Comments','Flag']
    elif selection == 'Coverity':
        headers = ['CID','Filepath','Function','Extra Details','Subcategory','Line Number','Description','Severity','Severity Level',
        'First Detected','External Reference','Triage Action','Triage Classification','First Occurence check','Merge Key','Present in Snapshot','Component','Comments','Flag']
    elif selection == 'Compiler_Warnings':
        headers = ['File_path','Line_number','Warning_info','Component','Comments','Flag']

    rows = []
    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first 1 line
                # print(row)  # this will print the whole table
                # print(row)[0]  # this will print the 1st column
                
                if selection == 'QAC':
                    filepath = row[0].replace('\\', '/')  # replace '\' with '/' because '\' makes re.match cannot work well
                    # 模糊处理cubas_gen中关于车型的名称，注意replace A18Y放在A18之前，防止生成AXXY这种错误结果
                    flag_this_row = filepath.replace('A13', 'AXX').replace('A18Y', 'AXX').replace('A29', 'AXX').replace('A18', 'AXX') + '; ' + row[4]
                    try:
                        this_row = [filepath,row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],flag_this_row]
                        print('Step 01 OK. @ "%s" Line %d' %(source_file, rowindex+1))
                    except:
                        this_row = [filepath,row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],'',flag_this_row]
                        print('Warning #01: No comments found in target file, filled it with an empty string. @ "%s" Line %d' %(source_file, rowindex+1))
                
                elif selection == 'Coverity':
                    filepath = row[1].replace('\\', '/')  # replace '\' with '/' because '\' makes re.match cannot work well
                    # 模糊处理cubas_gen中关于车型的名称，注意replace A18Y放在A18之前，防止生成AXXY这种错误结果
                    flag_this_row = filepath.replace('A13', 'AXX').replace('A18Y', 'AXX').replace('A29', 'AXX').replace('A18', 'AXX') + '; ' + row[6]
                    try:
                        this_row = [row[0],filepath,row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],row[17],flag_this_row]
                        print('Step 01 OK. @ "%s" Line %d' %(source_file, rowindex+1))
                    except:
                        this_row = [row[0],filepath,row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],'',flag_this_row]
                        print('Warning #01: No comments found in target file, filled it with an empty string. @ "%s" Line %d' %(source_file, rowindex+1))
                
                elif selection == 'Compiler_Warnings':
                    filepath = row[0].replace('\\', '/')  # replace '\' with '/' because '\' makes re.match cannot work well
                    # 模糊处理cubas_gen中关于车型的名称，注意replace A18Y放在A18之前，防止生成AXXY这种错误结果
                    flag_this_row = filepath.replace('A13', 'AXX').replace('A18Y', 'AXX').replace('A29', 'AXX').replace('A18', 'AXX') + '; ' + row[2]
                    try:
                        this_row = [filepath,row[1],row[2],row[3],row[4],flag_this_row]
                        print('Step 01 OK. @ "%s" Line %d' %(source_file, rowindex+1))
                    except:
                        this_row = [filepath,row[1],row[2],row[3],'',flag_this_row]
                        print('Warning #01: No comments found in target file, filled it with an empty string. @ "%s" Line %d' %(source_file, rowindex+1))
                
                rows.append(this_row)
            rowindex += 1

    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)

# 执行 Step01 - 遍历 source CSV
intersection_source_file_list_for_02 = []
intersection_target_file_list_for_02 = []
for source_file in intersection_source_file_list:
    target_file = source_file.replace('.csv', '_flag.csv')
    intersection_source_file_list_for_02.append(target_file)
    Step01(source_file, target_file)
# 遍历 target CSV
for source_file in intersection_target_file_list:
    target_file = source_file.replace('.csv', '_flag.csv')
    intersection_target_file_list_for_02.append(target_file)
    Step01(source_file, target_file)
        

# 提前准备全局list
comment_diff_list = []
print('')

# 读取每一个 source csv，生成对应的字典 （名称为 Source_XXX_dict.csv）
print('*** Step 02: Generating dictionary from each source file... \n')

def Step02(source_file, target_file):
    
    print('Step 02 running: @ "%s"' % source_file)
    
    # stat based on filename and severity
    headers = ['Flag','Comments', 'Num', 'Diff_Comments_Exist']
    rows = []

    flag_existed = []  # 记录所有已经存在的 flag： 如果是新的flag ，加入这个列表，如果是旧的flag ，将对应的num +1

    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first line
                # no need to replace '\' with '/' again
                
                r_flag = ''
                r_comments = ''
                
                if selection == 'QAC':
                    r_flag = row[12]
                    r_comments = row[11]
                
                elif selection == 'Coverity':
                    r_flag = row[18]
                    r_comments = row[17]
                    
                elif selection == 'Compiler_Warnings':
                    r_flag = row[5]
                    r_comments = row[4]
                
                if r_flag not in flag_existed:
                    flag_existed.append(r_flag)
                    this_row = [r_flag, r_comments, 1, 'No']  # Flag and Comments, number
                    rows.append(this_row)  # rows and flag_existed share the same index "p"
                else:
                    p = flag_existed.index(r_flag)  # return the index of an item within a list, start from 0
                    rows[p][2] += 1  # num所在的列index为2
                    # 检查此次读取的comment是否与第一个comment不同？
                    if r_comments != rows[p][1]:
                        rows[p][3] = 'Yes'
            rowindex += 1

    # 将所有标注了 diff = Yes 的行写入全局列表
    global comment_diff_list
    for item in rows:
        if item[3] == 'Yes':
            this_item = {}
            this_item['SourceCSV'] = source_file
            this_item['Flag'] = item[0]
            comment_diff_list.append(this_item)
            print('Warning #02: Different comments found from same file path and warning info. @ "%s", Flag: "%s"' %(source_file, item[0]))
    print('')  # leave an empty line

    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)
        
intersection_source_file_list_for_03 = []
for source_file in intersection_source_file_list_for_02:
    target_file = source_file.replace('_flag.csv', '_dict.csv')
    intersection_source_file_list_for_03.append(target_file)
    Step02(source_file, target_file)


# 功能函数，从给定的带有flag的csv文件中根据flag查找对应行的其他信息，返回一个二维list
def Search_by_flag(source_file, input_flag):

    search_result = []

    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first line
                # no need to replace '\' with '/' again
                
                r_flag = ''
                r_comments = ''
                r_filepath = ''
                r_warning_info = ''
                
                if selection == 'QAC':
                    r_flag = row[12]
                    r_comments = row[11]
                    r_filepath = row[0]
                    r_warning_info = row[4]
                
                elif selection == 'Coverity':
                    r_flag = row[18]
                    r_comments = row[17]
                    r_filepath = row[1]
                    r_warning_info = row[6]
                    
                elif selection == 'Compiler_Warnings':
                    r_flag = row[5]
                    r_comments = row[4]
                    r_filepath = row[0]
                    r_warning_info = row[2]
                
                if r_flag == input_flag:
                    this_result = []
                    # 'Line No from Source', 'File Path', 'Warning Info', 'Comments', 'Line No in Output'
                    search_result.append([rowindex+1, r_filepath, r_warning_info, r_comments, ''])
                    
            rowindex += 1
    
    return search_result

# 写几个 diff csv，记录可能的comment不同的情况，并不是每个source都会有对应的 diff csv
def Step02B(source_file, target_file):
    # stat based on filename and severity
    headers = ['Line No from Source', 'File Path', 'Warning Info', 'Comments', 'Line No in Output']
    rows = []
    
    global comment_diff_list  # 包含 source csv 名字和 flag
    for item in comment_diff_list:
        if source_file == item['SourceCSV']:
            
            # 第一次搜索source flag csv文件，最后一列留空
            source_2d_list = Search_by_flag(source_file, item['Flag'])
            # 第二次搜多 target flag csv 文件，然后将其中的行号提取出来，拼贴到上一次搜索的第一行结果的最后一列
            corresponding_file_name_as_target = source_file.replace('source/Source', 'target/Target')
            target_2d_list = Search_by_flag(corresponding_file_name_as_target, item['Flag'])
            line_number_in_output = ''
            for line in target_2d_list:
                line_number_in_output += (str(line[0]) + ', ')
            source_2d_list[0][4] = line_number_in_output
            
            # 将拼贴后的二维list加入结果中，【注意】这里用extend而不是append，不然会将二维list变成一个单独的元素
            rows.extend(source_2d_list)
            rows.append(['','','','',''])  # leave an empty line
    
    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)
        
    
# 读取每一个target csv，通过查字典，写入comments
print('*** Step 03: Migrating Comments...')

def Step03(source_file, dictionary_file, target_file):
    # stat based on filename and severity
    headers = []
    if selection == 'QAC':
        headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
        'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component','Comments']
    elif selection == 'Coverity':
        headers = ['CID','Filepath','Function','Extra Details','Subcategory','Line Number','Description','Severity','Severity Level',
        'First Detected','External Reference','Triage Action','Triage Classification','First Occurence check','Merge Key','Present in Snapshot','Component','Comments']
    elif selection == 'Compiler_Warnings':
        headers = ['File_path','Line_number','Warning_info','Component','Comments']
    
    comment_dict_list = []
    with open(dictionary_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first 1 line
                # print(row)  # this will print the whole table
                # print(row)[0]  # this will print the 1st column
                this_row = {'Flag':row[0], 'Comments':row[1]}
                comment_dict_list.append(this_row)
            rowindex += 1
    # print(comment_dict_list)
    
    rows = []
    with open(source_file)as f:
        f_csv = csv.reader(f)  # this returns an iterable object, use "for" to poll it
        rowindex = 0
        for row in f_csv:
            if rowindex >= 1:  # skip the first 1 line
                # print(row)  # this will print the whole table
                # print(row)[0]  # this will print the 1st column
                
                if selection == 'QAC':
                    r_flag = row[12]
                    r_comments = ''
                    
                    for i in comment_dict_list:
                        if r_flag == i['Flag']:
                            r_comments = i['Comments']
                    
                    this_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],r_comments]  # Do not need to print Flag again
                    
                    if r_comments == '':
                        print ('Warning #0301: Comments not found from source. @ "%s" Line %d' %(target_file, rowindex+1))
                    else:  # Comments found from source
                        if row[11].strip() != '':  # 防止覆盖原有的评论
                            print('Step 0302: Comments already exists in target file, do not overwrite it. @ "%s" Line %d' %(target_file, rowindex+1))
                            this_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11]]  # Do not need to print Flag again
                        else:
                            print('Step 0302 OK: Comments Migrated Done. @ "%s" Line %d' %(target_file, rowindex+1))
                        
                
                elif selection == 'Coverity':
                    r_flag = row[18]
                    r_comments = ''
                    
                    for i in comment_dict_list:
                        if r_flag == i['Flag']:
                            r_comments = i['Comments']
                    
                    this_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],r_comments]  # Do not need to print Flag again
                    
                    if r_comments == '':
                        print ('Warning #0301: Comments not found from source. @ "%s" Line %d' %(target_file, rowindex+1))
                    else:  # Comments found from source
                        if row[17].strip() != '':  # 防止覆盖原有的评论
                            print('Step 0302: Comments already exists in target file, do not overwrite it. @ "%s" Line %d' %(target_file, rowindex+1))
                            this_row = [row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],row[17]]  # Do not need to print Flag again
                        else:
                            print('Step 0302 OK: Comments Migrated Done. @ "%s" Line %d' %(target_file, rowindex+1))
                
                elif selection == 'Compiler_Warnings':
                    r_flag = row[5]
                    r_comments = ''
                    
                    for i in comment_dict_list:
                        if r_flag == i['Flag']:
                            r_comments = i['Comments']
                    
                    this_row = [row[0],row[1],row[2],row[3],r_comments]  # Do not need to print Flag again
                    
                    if r_comments == '':
                        print ('Warning #0301: Comments not found from source. @ "%s" Line %d' %(target_file, rowindex+1))
                    else:  # Comments found from source
                        if row[4].strip() != '':  # 防止覆盖原有的评论
                            print('Step 0302: Comments already exists in target file, do not overwrite it. @ "%s" Line %d' %(target_file, rowindex+1))
                            this_row = [row[0],row[1],row[2],row[3],row[4]]  # Do not need to print Flag again
                        else:
                            print('Step 0302 OK: Comments Migrated Done. @ "%s" Line %d' %(target_file, rowindex+1))
                
                rows.append(this_row)
            rowindex += 1

    # sometimes the either of the following 2 lines may not work, depending on different python versions
    # with open('test.csv','w', newline='')as f:
    with open(target_file,'w',newline='')as f:
        w_csv = csv.writer(f)
        w_csv.writerow(headers)
        w_csv.writerows(rows)

for dictionary_file in intersection_source_file_list_for_03:
    target_file = dictionary_file.replace('_dict.csv', '_target.csv').replace('source/Source', 'target/Target')
    source_file = target_file.replace('_target.csv', '_flag.csv')
    
    print('')
    print('Source: %s' % source_file)
    print('Target: %s' % target_file)
    print('Dictionary: %s' % dictionary_file)
    print('')
    
    Step03(source_file, dictionary_file, target_file)
    


############################## stage 03: Combine all CSV into XLSX  ################################

with open('temp/intersection_source_file_list.txt') as f:
    intersection_source_file_list = f.readlines()
    f.close()

intersection_source_file_list_2 = []
for i in intersection_source_file_list:
    intersection_source_file_list_2.append(i.strip().replace('temp/source/Source_Sheet_', '').replace('.csv', ''))

intersection_source_file_list = intersection_source_file_list_2
# print(intersection_source_file_list)


# set output file name and path
root_path = getcwd()
ls_target = listdir('%s/%s/target' % (root_path, input_folder))
    
if not ls_target == []:
    ls_target_0 = '99_output/' + ls_target[0]
    ls_target_0 = ls_target_0.replace('.xlsx', '_Updated.xlsx')
    print('\n*** Step 04: Set Output File: %s' % ls_target_0)
else:
    print('ERROR: Could Not find Target File, please check it under %s\\target\\ folder!' % input_folder)
    exit(1)

# An example for write an Excel from data in "dict" - which can be read from another XLSX file
'''
# An example for data format for XLSX (dict), each "key" is a column:
data = {
    'name':['Alice', 'Bob', 'Charlie'],
    'age':[11, 12, 13],
    'sex':['Female', 'Male', 'Male'],
}
'''
def writeExcelDemo():
    headers = ['Filename','Line number','Column number','Producer component:Message number','Message text','Severity',
            'Suppression type bitmask','Suppression justification','Rule Group','Rule text','Component']
    data = {}
    for header in headers:
        data[header] = []  # init a key in dict
        data[header].append('example')
    df = DataFrame(data)
    df.to_excel('target_file.xlsx', sheet_name='Sheet1', index=False, header=True)

# for a "data" (2-dimension list) convert numbers from str to int
def Str2Int(data):
    new_data = []
    for row in data.values:
        # change '/' to '\', only the first column
        try:
            if selection == 'QAC':
                row[0] = row[0].replace('/', '\\')
            elif selection == 'Coverity':
                row[1] = row[1].replace('/', '\\')
            else:  # This step is not need in Compiler Warnings
                pass
        except:
            pass
        # convert numbers from str to int
        new_row = []
        for col in row:
            try:
                new_col = int(col)
            except:
                new_col = col
            new_row.append(new_col)
        new_data.append(new_row)
    return new_data

# combine csv's of each component to an entire Excel table
def Step07():
    first_sheet_in_target_xlsx = ''
    if selection == 'QAC':
        first_sheet_in_target_xlsx = 'temp/target/Target_Sheet_QAC_QACPP_Warnings_Stat_new.csv'
    elif selection == 'Coverity':
        first_sheet_in_target_xlsx = 'temp/target/Target_Sheet_Coverity_Warnings_Stat.csv'
    elif selection == 'Compiler_Warnings':
        first_sheet_in_target_xlsx = 'temp/target/Target_Sheet_Compiler_Warnings_Warnings_Stat.csv'
        
    source_file_template = 'temp/target/Target_Sheet_'   # temp/target/Target_Sheet_BSW_C_target.csv
    target_file = ls_target_0

    # read first sheet from csv format, the output is 2-dimension list
    data = pd.read_csv(first_sheet_in_target_xlsx, sep=',', header=None)  # without attribute "header=None", the first line will be missing
    # convert numbers from str to int
    new_data = Str2Int(data)
    # prepare to write the sheet to Excel
    df0 = DataFrame(new_data)

    # read other sheets
    dfs = []
    for item in intersection_source_file_list:
        middleware_target = source_file_template + item + '_target.csv'
        # print(middleware_target)

        if path.exists(middleware_target):
            print("* Merging " + middleware_target)
            this_df = {}
            # read csv, if without attribute "header=None", the first line will be missing
            data = pd.read_csv(middleware_target, sep=',', header=None)
            # convert numbers from str to int
            new_data = Str2Int(data)
            # prepare to write the sheet to Excel
            this_df['sheet_title'] = item
            this_df['DF']= DataFrame(new_data)
            dfs.append(this_df)
        

    xlsx_file_name = ''
    if selection == 'QAC':
        xlsx_file_name = 'QAC_QACPP_Warnings_Stat_new'
    elif selection == 'Coverity':
        xlsx_file_name = 'Coverity_Warnings_Stat'
    elif selection == 'Compiler_Warnings':
        xlsx_file_name = 'Compiler_Warnings_Warnings_Stat'
    
    # *** Write Excel... ***
    # if only one sheet need:
    # df0.to_excel(target_file, sheet_name=xlsx_file_name, index=False, header=False)

    # if more than one sheets need:
    with pd.ExcelWriter(target_file) as writer:
        df0.to_excel(writer, sheet_name=xlsx_file_name, index=False, header=False)
        for df in dfs:
            df['DF'].to_excel(writer, sheet_name=df['sheet_title'], index=False, header=False)
        
        # Add Format
        Step07A(writer, selection, dfs, xlsx_file_name)
        

# 设置格式
def Step07A(writer, selection, dfs, xlsx_file_name):
    # Add Format
    workbook = writer.book
    header_format = workbook.add_format({'bold': True, 'border': 1, 'bg_color': '#00D060'})
    border_format = workbook.add_format({'border': 1})
    # hide_format = workbook.add_format({'display': False})  # 不知道怎么用？
    # hide_format = workbook.add_format({'hide': True})  # 不知道怎么用？
    
    keyword_list = ['ip_if', 'CUBAS', 'MAIN', 'SCOM']
    
    def set_width_and_header_color(worksheet, df = None, last_row_index = 0, last_col_index = 0):
        # 如果传入了df参数，根据df计算最后行列数，否则需要直接传入最后行列数
        if type(df).__name__ != 'NoneType':
            last_row_index = (len(df.values))       # 获取最后一行的行号
            last_col_index = len(df.values[0])      # 获取最后一列的列号
            # print(df.values[-1][-1])              # 显示右下角单元格内容
            # cell_range = '0, 0, %d, %d' %(last_row_index, last_col_index)  # 设置 sheet 所有格子范围
            
        # 设置边框 （从第二行开始）
        worksheet.conditional_format(1, 0, last_row_index-1, last_col_index-1, {'type': 'no_blanks', 'format': border_format})  # 非空值
        worksheet.conditional_format(1, 0, last_row_index-1, last_col_index-1, {'type': 'blanks', 'format': border_format})     # 空值
        # 设置表头颜色
        worksheet.conditional_format(0, 0, 0, last_col_index-1, {'type': 'no_blanks', 'format': header_format})     # 非空值，表头行没有空值
        
        return worksheet, last_row_index
    
    
    if selection == 'QAC':
        pass
        
    elif selection == 'Coverity':
        # Set col width: first sheet
        worksheet = writer.sheets[xlsx_file_name]
        worksheet.set_column('A:A', 30, border_format)
        worksheet.set_column('B:B', 20, border_format)
        worksheet.set_column('C:C', 20, border_format)
        worksheet.set_column('D:D', 20, border_format)
        worksheet.set_column('E:E', 20, border_format)
        worksheet.set_column('F:F', 14, border_format)
        worksheet.set_row(0, None, header_format)
        
        # Set col width: all other sheets
        for df in dfs:
            worksheet = writer.sheets[df['sheet_title']]
            worksheet.set_column('A:A', 8, border_format)
            worksheet.set_column('B:B', 80, border_format)
            worksheet.set_column('C:C', 8, border_format)  # 应当隐藏，但不知道怎么用？
            worksheet.set_column('D:E', 12, border_format)  # 应当隐藏，不知道怎么用？
            worksheet.set_column('F:F', 12, border_format)
            worksheet.set_column('G:G', 120, border_format)
            worksheet.set_column('H:P', 8, border_format)  # 应当隐藏，不知道怎么用？
            worksheet.set_column('Q:Q', 12, border_format)
            worksheet.set_column('R:R', 60, border_format)
            worksheet.set_row(0, None, header_format)
        
    elif selection == 'Compiler_Warnings':
        # Set col width: first sheet
        worksheet = writer.sheets[xlsx_file_name]
        # 设置列宽
        worksheet.set_column('A:A', 40)
        worksheet.set_column('B:B', 14)
        # 设置边框和表头颜色，注意这里没有df可以传入，需要手写最后一行的行号
        worksheet = set_width_and_header_color(worksheet, last_row_index = 26, last_col_index = 2)[0]
        
        # Set col width: all other sheets
        for df in dfs:
            worksheet = writer.sheets[df['sheet_title']]
            # 设置列宽
            worksheet.set_column('A:A', 80)
            worksheet.set_column('B:B', 12)
            worksheet.set_column('C:C', 120)
            worksheet.set_column('D:D', 12)
            worksheet.set_column('E:E', 60)
            # 设置边框和表头颜色，会根据df自动计算最后行号
            worksheet, last_row_index = set_width_and_header_color(worksheet, df = df['DF'])
            # 设置sheet标签的颜色
            for keyword in keyword_list:
                if keyword in df['sheet_title']:
                    worksheet.set_tab_color("#7F7F7F")
            # 修正第一页的统计数字（去掉重复项后的）
            print(df['sheet_title'].replace('_Warnings', '') + ',' + str(last_row_index - 1))
        
    writer.save()

# 将 diff_comments 零散的csv文件合并成xlsx
def Step07B():
    global comment_diff_source_csv_list
        
    source_file_template = 'temp/diff_comments/Diff_Comments_'   # temp/diff_comments/Diff_Comments_BSW_C_target.csv
    target_file = diff_comment_output_file_path

    # read other sheets
    dfs = []
    
    for i in comment_diff_source_csv_list:
        item = i.strip().replace('temp/source/Source_Sheet_', '').replace('_flag.csv', '')
        middleware_target = source_file_template + item + '_flag.csv'
        # print(middleware_target)

        if path.exists(middleware_target):
            print("* Merging " + middleware_target)
            this_df = {}
            # read csv, if without attribute "header=None", the first line will be missing
            data = pd.read_csv(middleware_target, sep=',', header=None)
            # convert numbers from str to int
            new_data = Str2Int(data)
            # prepare to write the sheet to Excel
            this_df['sheet_title'] = item
            this_df['DF']= DataFrame(new_data)
            dfs.append(this_df)
    
    # *** Write Excel... ***
    # if only one sheet need:
    # df0.to_excel(target_file, sheet_name=xlsx_file_name, index=False, header=False)

    # if more than one sheets need:
    with pd.ExcelWriter(target_file) as writer:
        for df in dfs:
            df['DF'].to_excel(writer, sheet_name=df['sheet_title'], index=False, header=False)

print("Merging CSV to XLSX...")
Step07()

# 将全局列表中出现过的 source csv 单独整理出来，针对这几个文件单独处理 diff comments
diff_comment_output_file_path = '99_output/Different_Comments_Checklist_%s.xlsx' % selection
comment_diff_source_csv_list = []
if len(comment_diff_list) > 0:
    for item in comment_diff_list:
        if item['SourceCSV'] not in comment_diff_source_csv_list:
            comment_diff_source_csv_list.append(item['SourceCSV'])
            
    print('\n*** Warning #05: There are some sheets containing different comments for same file path and warning info, please check them from: "%s"' % diff_comment_output_file_path)
    for source_file in comment_diff_source_csv_list:
        # print(' - ' + source_file)
        target_file = source_file.replace('source/Source_Sheet_', 'diff_comments/Diff_Comments_')
        Step02B(source_file, target_file)
        
    print('')
    Step07B()
else:
    print('\n*** Step 05: There are no different comments for same file path and warning info, skip this step.')

# 前面可能有遗留的警告信息，在结尾显示
if there_are_messages_to_be_printed_in_the_end:
    print('\n' + messages_to_be_printed_in_the_end)

print("\nAll Finished.\nOutput: %s" % ls_target_0)
if len(comment_diff_list) > 0:
    print("Output: %s" % diff_comment_output_file_path)
if source_but_not_target_file_list != []:
    print("Output: 99_output/source_but_not_target_sheets_%s.txt" % selection)
if target_but_not_source_file_list != []:
    print("Output: 99_output/target_but_not_source_sheets_%s.txt" % selection)

print("")  # leave an empty line

