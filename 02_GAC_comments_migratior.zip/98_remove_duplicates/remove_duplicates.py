# -*- coding: utf-8 -*-

'''this script is recommanded to run under python3'''

import pandas as pd
from pandas import DataFrame
import sys

input_file_name = str(sys.argv[1])
output_file_name = input_file_name.replace('.xlsx', '_removed_duplicates.xlsx')

def convert_xlsx_to_csv (source_file, sheet_name, target_file, remove_duplicates=True):
    if remove_duplicates:
        print("Removing Duplicated Lines @ %s..." % sheet_name)
    data = pd.read_excel(source_file, sheet_name, index_col=0)  # without attribute "index_col=0", there will be an extra colomn at the beginning of csv
    if remove_duplicates:
        data.drop_duplicates(subset=None, keep='first', inplace=True)  # remove all duplicated lines
    data.to_csv(target_file, encoding='utf-8')

# combine csv's of each component to an entire Excel table
def merge_csv_to_xlsx(sheet_name_list):
    target_file = output_file_name

    dfs = []
    for sheet_name in sheet_name_list:
        print("Merging CSV to XLSX @ %s..." % sheet_name)
        source_file = 'temp/%s.csv' % sheet_name
        this_df = {}
        # read first sheet from csv format, the output is 2-dimension list
        data = pd.read_csv(source_file, sep=',', header=None)  # without attribute "header=None", the first line will be missing
        # prepare to write the sheet to Excel
        this_df['sheet_title'] = sheet_name
        this_df['DF']= DataFrame(data)
        dfs.append(this_df)
    
    # *** Write Excel... ***
    # if only one sheet need:
    # df0.to_excel(target_file, sheet_name='QAC_QACPP_Warnings_Stat_new', index=False, header=False)

    # if more than one sheets need:
    with pd.ExcelWriter(target_file) as writer:
        for df in dfs:
            df['DF'].to_excel(writer, sheet_name=df['sheet_title'], index=False, header=False)



# get all sheet names
sheet_name_list = pd.read_excel(input_file_name, sheet_name=None).keys()

num = 0
for i in sheet_name_list:
    target_file = 'temp/%s.csv' % i
    # ignore deplicates in first sheet
    if num == 0:
        convert_xlsx_to_csv (input_file_name, i, target_file, remove_duplicates=False)
    else:
        convert_xlsx_to_csv (input_file_name, i, target_file)
    num += 1

# merge all csv back to xlsx
print("")
merge_csv_to_xlsx(sheet_name_list)

